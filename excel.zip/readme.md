# Conversion 

## Requirements

- For BD: 
1. 

-- If Assign Maximum in Transit Date is later than Date of Issue, account for the allocate in transite warehouse. Otherwise, take the owed quantity. 

## Install 
1. Go to your terminal / command prompt and 

2. Create a data folder (in the same level as this file)

3. Put in your 

4. Go to variables.js and change the file names 

5. Go back to your terminal, make sure you are in the current directory 
-- cd desktop
-- cd 
-- node run.js 

6. Your files should be in the output folder 


