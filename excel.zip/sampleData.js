[
  {
    key: "TAC00070840",
    beforeSum: 13.203000000000001,
    afterSum: 31.644000000000002,
  },
  {
    key: "TAC01114990",
    beforeSum: 0,
    afterSum: 0.878,
  },
  {
    key: "TAC11173780",
    beforeSum: 6.346,
    afterSum: 0,
  },
  {
    key: "TAC11179620",
    beforeSum: 2.401,
    afterSum: 0,
  },
  {
    key: "TAC11179670",
    beforeSum: 24.409,
    afterSum: 0.528,
  },
  {
    key: "TAC11179680",
    beforeSum: 71.53999999999999,
    afterSum: 0,
  },
  {
    key: "TAC11179770",
    beforeSum: 6.18,
    afterSum: 0,
  },
  {
    key: "TAC11181200",
    beforeSum: 37.65,
    afterSum: 36.308,
  },
  {
    key: "TAC11181440",
    beforeSum: 0,
    afterSum: 1.9180000000000001,
  },
  {
    key: "TAC11184580",
    beforeSum: 6.862,
    afterSum: 0,
  },
  {
    key: "TAC11187880",
    beforeSum: 77.441,
    afterSum: 0,
  },
  {
    key: "TAF11178770",
    beforeSum: 9.256,
    afterSum: 0,
  },
];
